import { DetailsPage } from './../details/details';
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  public schools;
  public filterList;
  postalCode;
  district;
  name;
  location;

  constructor(public navCtrl: NavController) {

  }

  ionViewDidLoad() {
    this.schools = new Array();
    this.initializeItems();
  }

  uploadFile(event) {
    console.log(event.srcElement.files);
    const reader = new FileReader();

    reader.onload = (e: any) => {

      var rows = e.target.result.split("\n");
      for (let i = 1; i < rows.length - 1; i++) {
        var fields = "";
        var fields2 = []
        fields = rows[i].split(';');
        fields2 = fields[0].split(",")

        var school = {
          "PK": fields2[0],
          "Name": fields2[1],
          "Equipment": fields2[2],
          "Transport": fields2[3],
          "Description": fields2[4],
          "Access": fields2[5],
          "Content_URL": fields2[6],
          "Street_Name": fields2[7],
          "Number": fields2[8],
          "Postal_Code": fields2[9],
          "Borough": fields2[10],
          "District": fields2[12],
          "Latitude": fields2[14],
          "Longitude": fields2[15],
          "Phone": fields2[16],
        }
        this.schools.push(school);
      }
    };
    reader.readAsText(event.target.files[0]);
    console.log(this.schools);
  }

  initializeItems(): void {
    this.filterList = this.schools;
  }

  onInput(searchbar) {
    this.initializeItems();
    var q = searchbar.srcElement.value;
    if (!q) {
      return;
    }
    if(this.filterList != undefined){
      this.filterList = this.filterList.filter((v) => {
        if(this.name == true){
          if (v.Name && q) {
            if (v.Name.toLowerCase().indexOf(q.toLowerCase()) > -1) {
              return true;
            }
            return false;
          }
        }
        if(this.district == true){
          if (v.District && q) {
            if (v.District.toLowerCase().indexOf(q.toLowerCase()) > -1) {
              return true;
            }
            return false;
          }
        }
        if(this.location == true){
          if (v.Street_Name && q) {
            if (v.Street_Name.toLowerCase().indexOf(q.toLowerCase()) > -1) {
              return true;
            }
            return false;
          }
        }
        if(this.postalCode == true){
          if (v.Postal_Code && q) {
            if (v.Postal_Code.toLowerCase().indexOf(q.toLowerCase()) > -1) {
              return true;
            }
            return false;
          }
        }

      });
    }

  }

  details(school) {
    this.navCtrl.push(DetailsPage, {'school': school })
  }


}
