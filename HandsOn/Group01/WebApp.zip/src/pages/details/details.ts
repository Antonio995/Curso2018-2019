import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import 'rxjs/add/operator/map';
import {
  GoogleMaps,
  GoogleMap,
  GoogleMapsEvent,
  GoogleMapOptions,
  CameraPosition,
  MarkerOptions,
  Marker,
  LatLng
 } from '@ionic-native/google-maps';

 declare var google: any;

@IonicPage()
@Component({
  selector: 'page-details',
  templateUrl: 'details.html',
})
export class DetailsPage {
  public school;
  public lat;
  public lng;

  public marker: Marker;

  public map;


  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.school = this.navParams.get("school");
    this.lat = this.school.Latitude;
    this.lng = this.school.Longitude;
  }

  ionViewDidLoad() {
    this.initMap();
    this.school = this.navParams.get("school");
    console.log('ionViewDidLoad DetailsPage');
    console.log(this.school);
  }

  initMap() {
    this.map = new google.maps.Map(document.getElementById('map'), {
      center: {lat: +this.lat, lng: +this.lng},
      zoom: 10,
      mapTypeId: 'roadmap'
    });
    this.placeMarker();


  }
  placeMarker(){
    var myLatLng = {lat: +this.lat, lng: +this.lng};
    console.log(myLatLng)
    this.marker = new google.maps.Marker({
      position: myLatLng,
      map: this.map,
    });
  }

}
